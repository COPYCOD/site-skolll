import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

export const config = { path: "/api" };

// Початкові дані (клас, учні, цикл). Використовуються, доки ви не натиснете «Зберегти».
const SEED = {"cls":"7-Б клас","week1":"2026-10-19","students":["Ільків Владислав","Іляш Денис","Бабенко Ростислав","Богдан Олег","Василик Назар","Вишньовська Вероніка","Грошко Денис","Данилишин Володимир","Драбиняста Настя","Дудяк Тетяна","Задорович Ігор","Клак Вікторія","Кузь Марта","Кузьо Назарій","Решетнікова Єва","Старик Матвій","Яремчук Віталій"],"cycle":[[["Богдан Олег","Яремчук Віталій"],["Кузьо Назарій","Ільків Владислав"],["Грошко Денис","Задорович Ігор"],["Данилишин Володимир","Іляш Денис"],["Старик Матвій","Бабенко Ростислав"]],[["Василик Назар","Іляш Денис"],["Кузь Марта","Дудяк Тетяна"],["Решетнікова Єва","Вишньовська Вероніка"],["Клак Вікторія","Драбиняста Настя"],["Богдан Олег","Яремчук Віталій"]]],"overrides":{},"absent":{}};

const LAT = { A: "А", B: "В", C: "С", E: "Е", H: "Н", I: "І", K: "К", M: "М", O: "О", P: "Р", T: "Т", X: "Х" };
const WORDS = ["fox", "owl", "cat", "sun", "sky", "sea", "ice", "bee", "kit", "oak", "fish", "bird", "tree", "rain", "wind", "snow", "leaf", "moon", "star", "wolf"];
const norm = (s) => String(s || "").trim().toUpperCase().replace(/[A-Z]/g, (c) => LAT[c] || c);
const ADMIN_N = norm("ADMIN");

const json = (d, c = 200, h = {}) => new Response(JSON.stringify(d), {
  status: c, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...h },
});
const hashPw = (pw, salt) => crypto.scryptSync(String(pw), salt, 32).toString("hex");
const sha = (s) => crypto.createHash("sha256").update(String(s)).digest();
const sign = (v) => crypto.createHmac("sha256", process.env.SESSION_SECRET).update(v).digest("hex");
const cookie = (v, age) => "s=" + encodeURIComponent(v) + "; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=" + age;

function mkLogin(name, taken) {
  const p = name.trim().toUpperCase().split(" "), S = Array.from(p[0]), N = Array.from(p[1] || p[0]);
  for (const c of N) { const l = S[0] + c; if (!taken.has(l)) return l; }
  for (let i = 1; i < S.length; i++) { const l = S[i] + N[0]; if (!taken.has(l)) return l; }
  for (let i = 1; ; i++) { const l = S[0] + N[0] + i; if (!taken.has(l)) return l; }
}
function mkPass(used) {
  let p;
  do { p = WORDS[crypto.randomInt(WORDS.length)] + crypto.randomInt(10, 100); } while (used.has(p));
  used.add(p); return p;
}
function session(req) {
  const m = /(?:^|; )s=([^;]+)/.exec(req.headers.get("cookie") || "");
  if (!m) return null;
  const [login, exp, sig] = decodeURIComponent(m[1]).split("|");
  if (!sig || Date.now() > +exp) return null;
  const want = sign(login + "|" + exp);
  if (sig.length !== want.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(want))) return null;
  return login;
}

export default async (req) => {
  if (!process.env.SESSION_SECRET || !process.env.ADMIN_PASSWORD) return json({ error: "config" }, 500);
  const a = new URL(req.url).searchParams.get("a");
  const store = getStore({ name: "duty", consistency: "strong" });
  try {
    if (a === "state") {
      const t = await store.get("state");
      return new Response(t || JSON.stringify(SEED), { headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });
    }
    const users = (await store.get("users", { type: "json" })) || {};
    const login = session(req), isAdmin = login === ADMIN_N, u = login && !isAdmin ? users[login] : null;

    if (a === "me") {
      const r = { name: isAdmin ? "Адміністратор" : u ? u.name : "", admin: isAdmin };
      if (isAdmin) r.have = Object.values(users).map((x) => x.name);
      return json(r);
    }
    if (req.method !== "POST") return json({ error: "method" }, 405);
    const raw = await req.text();
    let body = {}; try { body = JSON.parse(raw) || {}; } catch {}

    if (a === "login") {
      const l = norm(body.login), pw = String(body.password || "");
      let ok = false;
      if (l === ADMIN_N) ok = crypto.timingSafeEqual(sha(pw), sha(process.env.ADMIN_PASSWORD));
      else if (users[l]) ok = crypto.timingSafeEqual(Buffer.from(hashPw(pw, users[l].salt)), Buffer.from(users[l].hash));
      if (!ok) { await new Promise((r) => setTimeout(r, 700)); return json({ error: "bad" }, 401); }
      const exp = Date.now() + 30 * 864e5;
      return json({ ok: true }, 200, { "Set-Cookie": cookie(l + "|" + exp + "|" + sign(l + "|" + exp), 2592000) });
    }
    if (a === "logout") return json({ ok: true }, 200, { "Set-Cookie": cookie("", 0) });
    if (!isAdmin) return json({ error: "auth" }, 403);

    if (a === "save") {
      if (raw.length > 300000 || !body.students || !body.cycle || !body.overrides || !body.absent) return json({ error: "bad" }, 400);
      await store.set("state", raw);
      return json({ ok: true });
    }
    if (a === "accounts") {
      const names = (Array.isArray(body.names) ? body.names : []).map((n) => String(n).trim()).filter(Boolean);
      const taken = new Set(Object.keys(users)); taken.add(ADMIN_N);
      const byName = {}; for (const [k, v] of Object.entries(users)) byName[v.name] = k;
      const used = new Set(), list = [];
      for (const n of names) {
        let lg = byName[n];
        if (lg && !body.reset) continue;
        if (!lg) { lg = mkLogin(n, taken); taken.add(lg); }
        const pw = mkPass(used), salt = crypto.randomBytes(16).toString("hex");
        users[lg] = { name: n, salt, hash: hashPw(pw, salt) };
        list.push({ login: lg, password: pw, name: n });
      }
      if (list.length) await store.set("users", JSON.stringify(users));
      return json({ list });
    }
    return json({ error: "unknown" }, 404);
  } catch (e) {
    return json({ error: "server" }, 500);
  }
};
